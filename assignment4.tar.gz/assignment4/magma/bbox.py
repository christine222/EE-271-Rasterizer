import magma as m
m.set_mantle_target("coreir")
import mantle
from mantle import Register
from magma import DefineCircuit, DeclareCircuit, Array, In, SInt, Out, wire, EndCircuit
import fault
from magma import BitVector
import sys
import mantle

import dff 
from rast_types import *
import tester

# Some helper functions...
def DefineMin2(bits):
    '''
    Returns a circuit that returns minimum of two signed integers of bitwidth bits
    '''
    class Min2(m.Circuit):
        IO = ["in0", m.In(m.SInt[bits]),
              "in1", m.In(m.SInt[bits]),
              "out", m.Out(m.SInt[bits])]

        @m.circuit.combinational
        def min2_(in0 : m.SInt[bits], in1 : m.SInt[bits]) -> (m.SInt[bits]):
            if in0 < in1:
                out = in0
            else:
                out = in1
            return (out)
        
        @classmethod                                                                    
        def definition(io):
            m.wire(io.out, io.min2_(io.in0, io.in1))
    return Min2

def DefineMax2(bits):
    '''
    Returns a circuit that returns maximum of two signed integers of bitwidth bits
    '''
    class Max2(m.Circuit):
        IO = ["in0", m.In(m.SInt[bits]),
              "in1", m.In(m.SInt[bits]),
              "out", m.Out(m.SInt[bits])]

        @m.circuit.combinational
        def max2_(in0 : m.SInt[bits], in1 : m.SInt[bits]) -> (m.SInt[bits]):
            if in0 > in1:
                out = in0
            else:
                out = in1
            return (out)
        
        @classmethod                                                                    
        def definition(io):
            m.wire(io.out, io.max2_(io.in0, io.in1))
    return Max2

def DefineMinN(n, bits):
    '''
    Returns a circuit that returns the minimum of an array of n signed integers with bitwidth bits
    '''
    assert(n > 0)

    class Min(m.Circuit):

        IO = ["input", m.In(m.Array[n, m.SInt[bits]]),
              "out", m.Out(m.SInt[bits])]

        @classmethod
        def definition(io):
            mins = [DefineMin2(bits)() for i in range(n-1)]
                                                                    
            mod = m.fold(mins, foldargs={"in0":"out"})
            m.wire(io.input[0], mod.in0)
            m.wire(io.input[1:], mod.in1)
            m.wire(io.out, mod.out)
    return Min

def DefineMaxN(n, bits):
    '''
    Returns a circuit that returns the maximum of an array of n signed integers with bitwidth bits
    '''
    assert(n > 0)

    class Max(m.Circuit):

        IO = ["input", m.In(m.Array[n, m.SInt[bits]]),
              "out", m.Out(m.SInt[bits])]

        @classmethod
        def definition(io):
            duts = [DefineMax2(bits)() for i in range(n-1)]
                                                                    
            mod = m.fold(duts, foldargs={"in0":"out"})
            m.wire(io.input[0], mod.in0)
            m.wire(io.input[1:], mod.in1)
            m.wire(io.out, mod.out)
    return Max

'''
def make_name_compute_bounding_box(integer_bits, fractional_bits, axes, color_channels, pipe_depth):
        return (f"ComputeBoundingBox_integer_bits_{integer_bits}_"
                f"_fractional_bits_{fractional_bits}_"
                f"_axes_{axes}_"
                f"_color_channels_{color_channels}_"
                f"_pipe_depth_{pipe_depth}")
'''

def define_compute_bounding_box(integer_bits, fractional_bits, axes, color_channels, pipe_depth):
    
    bits = integer_bits + fractional_bits
    
    assert(axes >= 2)
    assert(pipe_depth >= 1)
    assert(integer_bits >= 1)
    assert(fractional_bits >= 0)

    class ComputeBoundingBox(m.Circuit):
        #name = make_name_compute_bounding_box(integer_bits, fractional_bits, axes, color_channels, pipe_depth)

        IO = ["RESET", m.In(m.Reset),
              "valid_in", m.In(m.Bits[1]),
              "tri_in", m.In(Triangle(axes, bits)),
              "color_in", m.In(Colors(color_channels, bits)),
              "screen_max", m.In(Point(2, bits)),
              "sample_size", m.In(SampleSize),
              "halt", m.In(m.Bits[1]),
              "valid_out", m.Out(m.Bits[1]),
              "tri_out", m.Out(Triangle(axes, bits)), 
              "color_out", m.Out(Colors(color_channels, bits)),
              "box", m.Out(Box(2, bits)),
              "is_quad_in", m.In(m.Bits[1]),
              "is_quad_out", m.Out(m.Bits[1]),
              "CLK", m.In(m.Clock)]
         
        # START CODE HERE
        # Potentially put helper functions here...
        # END CODE HERE

        @classmethod
        def definition(io):
            # START CODE HERE
            # -------------------
            # Your code goes here
            # -------------------
            # You may define any combinational functions you may need
            # Finally, assign values to
            #   box_clamped
            #   box_valid
            # These signals feed into the pipeline registers
            # -------------------
            # Your code goes here
            # -------------------
            # END CODE HERE

            # Put values into pipeline registers
            def wire_reg (reg, reg_input, reg_output=None):
                m.wire(reg_input, reg.data_in)
                m.wire(reg.clk,io.CLK)
                m.wire(reg.reset, io.RESET)
                m.wire(reg.en, io.halt[0])
                if reg_output is not None:
                    m.wire(reg.data_out, reg_output)
            
            tri_retime_r = dff.DefineDFF3(axes, 3, bits, pipe_depth - 1, 1)()
            wire_reg(tri_retime_r, io.tri_in)
            
            tri_r = dff.DefineDFF3(axes, 3, bits, 1, 0)()
            wire_reg(tri_r, tri_retime_r.data_out, io.tri_out)
            
            color_retime_r = dff.DefineDFF2(color_channels, bits, pipe_depth - 1, 1)()
            wire_reg(color_retime_r, io.color_in)

            color_r = dff.DefineDFF2(color_channels, bits, 1, 0)()
            wire_reg(color_r, color_retime_r.data_out, io.color_out)

            box_retime_r = dff.DefineDFF3(2, 2, bits, pipe_depth - 1, 1)()
            wire_reg(box_retime_r, box_clamped)
            
            box_r = dff.DefineDFF3(2, 2, bits, 1, 0)()
            wire_reg(box_r, box_retime_r.data_out, io.box)
 
            valid_retime_r = dff.DefineDFF(1, pipe_depth - 1, 1)()
            wire_reg(valid_retime_r, box_valid)

            valid_r = dff.DefineDFF(1, 1, 0)()
            wire_reg(valid_r, valid_retime_r.data_out, io.valid_out)

            is_quad_retime_r = dff.DefineDFF(1, pipe_depth - 1, 1)()
            wire_reg(is_quad_retime_r, m.bits(io.is_quad_in))

            is_quad_r = dff.DefineDFF(1, 1, 0)()
            wire_reg(is_quad_r, is_quad_retime_r.data_out, m.bits(io.is_quad_out))

    return ComputeBoundingBox

def define_dut():
    integer_bits = 14
    fractional_bits = 10
    axes = 3
    color_channels = 3
    pipe_depth = 3

    dut = define_compute_bounding_box(integer_bits, fractional_bits, axes, color_channels, pipe_depth)
    return dut

def test_dut():
    dut = define_dut()
    m.config.set_debug_mode(True)
    m.compile('build/' + dut.name, dut, output="coreir-verilog")
    testbench = tester.Tester(dut, tester.pack_vectors(dut, dut.name + '_vector.json', 10000))
    testbench.compile_and_run(directory="build", target="verilator", flags=["-Wno-fatal", '--trace'])

#test_dut()
