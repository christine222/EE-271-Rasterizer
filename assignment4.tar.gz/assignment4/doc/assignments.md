This project is broken into three assignments. The first assignment will challenge you to understand the hardware design. The second assignment will require you to complete RTL implementation and synthesize the whole design. Finally, the third assignment will challenge you to increase the performance or the energy efficiency of the design to meet specifications.

  * [Assignment 1](assignment1.md) 
  * [Assignment 2](assignment2.md) 
  * [Assignment 3](assignment3.md) 
