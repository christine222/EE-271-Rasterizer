# Micropolygon Rasterization Overview

Recall that the goal of rasterization is to determine which fragments correspond to which micropolygons in an image. To make the problem  easier, we have broken it into two steps: first determine which fragments we should test against the micropolygon and second determine if the fragments lie inside the micropolygon. We will refer to the first as the bounding box problem and the second as the sample test problem.

## Bounding Box

![Axis Aligned Bounding Box 16xMSAA](img/figure6.png)

Figure 6: Axis Aligned Bounding Box 16xMSAA

The naive solution for determining the set of samples (fragments) to test is the set of all samples on the screen. This is extremely inefficient and would require a significant number of sample tests. To reduce the number of sample tests we can calculate an axis aligned bounding box for the microploygon which would limit the number of samples we are required to test. A bounding box can be calculated using the minimum x coordinate of the vertices, the minimum y coordinate of the vertices, the maximum x coordinated of the vertices, and the maximum y coordinate of the vertices. The axis aligned bounding box is shown in Figure 6 in red while the micropolygon is shown in black and the fragment sample locations are shown as blue circles.

While this axis aligned bounding box is a boundary for both the micropolygon and the set of fragments that exist inside it, it does not  describe the set of fragments to test. To do this we would like to round the coordinates to nearby fragments, so that the sample set can be described as iterating from the lower left coordinate to the upper right coordinate in a left to right and down to up pattern. Because we will be sampling the region with jittered sampling, we will need to make sure that our clamped bounding box includes all of pixels whose randomly distributed samples could lie inside the micropolygon. This optimally clamped bounding box is shown in green in Figure 6.

Finally, it is desirable to clip the bounding box to the screen space so that fragments which lie outside the image are not tested against the polygons. The clip operation simply replaces one of the lower-left coordinate value with 0 if it is less then zero, or one of the upper right coordinates with the image width/height if its value is out of bounds. Finally, in the cases where the bounding box does not appear on the screen at all, it is useful to reject the micropolygon entirely.

## Sample in Polygon Test

The goal for a sample test is to convert the geometric properties of a point in a polygon into an equation that can be evaluated as true or false. The approach we take is to use edge equations. Edge equations can be used to indicate whether a sample lies to the left, right, or on a directed edge.

In the simple case of a triangle, when the sample lies to the same side of all edges, the sample can be considered to lie inside the micropolygon.

* A micropolygon triangle is defined by three vertices `(v1, v2, v3)` where `v1 = (x1, y1)` and so on.

* Edges are defined by two vertices, for example `(v1, v2)` is an edge from `v1` to `v2`.

* An equation for the edge can be given in the form:
    ```
    (y - y1)/(x - x1) = (y2 - y1)/(x2 - x1) = slope
    ```
    or
    ```
    (y - y1)(x2 - x1) = (y2 - y1)(x - x1)
    ```

* Given a sample position `(x, y)`, it is useful to make a coordinate shift such that the sample resides on the `(0, 0)` position. This is a shift of `-x` for X coordinates and `-y` for Y coordinates. Define:
    ```
    xl' = xl - x
    yl' = yl - y
    x2' = x2 - x
    y2' = y2 - y
    ```
    Now we test our `(x, y)` point by placing it in the equation for the edge described above:
    ```
    0 = x1'y2' - x2'y1'
    ```
* If the origin is not on the line: 
    ```
    0 != x1'y2' - x2'y1'
    ```
* If the origin lies to the left of the line: 
    ```
    0 < x1'y2' - x2'y1'
    ```
* If the origin lies to the right of the line: 
    ```
    0 > x1'y2' - x2'y1'
    ```
* For example, 
    * `v1 = (1, 0)`, `v2 = (0, l)`, `vs = (0, 0)` (Figure 7):
        * `1 · 1 - 0 · 0 > 0` therefore left of line.
   
        ![Edge Test 1 - Left of Edge](img/figure7.png)
    
        Figure 7: Edge Test 1 - Left of Edge
   
    * `v1 = (0, 1)`, `v2 = (1, 0)`, `vs = (0, 0)` (Figure 8):
        * `0 . 0 - 1 . 1 < 0` therefore right of line.
   
        ![Edge Test 2 - Right of Edge](img/figure8.png)
    
        Figure 8: Edge Test 2 - Right of Edge

    * Given a triangle `v1 = (-2, 3), v2 = (-1, -1), v3 = (2, -1)` and sample `vs = (0, 0)` (Figure 9):
        * e1: `-2 · -1 - -1 · 3 =  5 > 0` therefore left of line
        * e2: `-1 · -1 - 2 · -1 = 3 > 0` therefore left of line
        * e3: `2 · 3 - -2 · -1 = 4 > 0` therefore left of line 
        
        Therefore the point must lie inside the triangle.
        
        ![Edge Test 3 - Point Inside](img/figure9.png)

        Figure 9: Edge Test 3 - Point Inside
        
    * Given a triangle `v1 = (-2, 3), v2 = (2, -1), v3 = (-1, -1)` and sample `vs = (0, 0)` (Figure 10):
        * e1: `-2 . -1 - 2 . 3 = -4 < 0` therefore right of line
        * e2: `2 . -1 - -1 . -1 = -3 < 0` therefore right of line
        * e3: `-1 . 3 - -2 . -1 = -5 < 0` therefore right of line 
        
        Therefore the point must lie inside the triangle.
    
        ![Edge Test 4 - Point Inside](img/figure10.png)

        Figure 10: Edge Test 4 - Point Inside
        
    * Given a triangle `v1 = (-2, 3), v2 = (-1, -1), v3 = (0, -1)` and sample `vs = (0, 0)` (Figure 11):    
        * e1: `-2 . -1 - -1 . 3 = 5 > 0` therefore left of line
        * e2: `-1  . -1  -  2 . -1 = 3 > 0` therefore left of line
        * e3: `0 . 3 - -2 . -1 = -2 < 0` therefore right of line 
        
        Therefore the point must lie outside the triangle.

        ![Edge Test 4 - Point Outside](img/figure11.png)

        Figure 11: Edge Test 4 - Point Outside

In many graphics systems, two dimensional polygons are considered to have a facing. This means that viewed from one side a polygon is visible, and  from  the  other  it  is not. This is useful in reducing the amount of work required, as back-facing, or looking away from  the display, polygons can be removed. In our case, when the sample point lies to the right of all of the edges then the sample lies inside a forward facing micropolygon, otherwise the sample test fails. This is referred to as back-face culling and corresponds to accepting the sample point in Figure 10 and rejecting the sample point in Figure 9.

### Pseudo Code

Pseudo code for micropolygon rasterization with triangles only:

```
void rast(vector<u_Poly> polys){
    for(i = 0; i < polys.size(); i++){
        rast_uPoly(polys[i]);
    } 
}
 
void rast_uPoly(poly){

    // Calculate clamped bounding box 
    // ll = lower left, ur = upper right

    // Min x rounded down to subsample grid
    ll_x = FLOOR_SS(MIN(x coordinate of poly vertices));
    // Max x rounded down to subsample grid
    ur_x = FLOOR_SS(MAX(x coordinate of poly vertices));
    // Min y rounded down to subsample grid
    ll_y = FLOOR_SS(MIN(y coordinate of poly vertices)); 
    // Max y rounded down to subsample grid
    ur_y = FLOOR_SS(MAX(y coordinate of poly vertices)); 
    
    // Clip bounding box to visible screen space
    
    ur_x = ur_x > screen_width ? screen_width : ur_x;
    ur_y = ur_y > screen_height ? screen_height	: ur_y;
    ll_x = ll_x < 0 ? 0 : ll_x;
    ll_y = ll_y < 0 ? 0 : ll_y;

    // Iterate over samples, test if in micropolygon
    // Note that offscreen bounding boxes are rejected by for loop test
    
    for(sl_x = ll_x; sl_x <= ur_x; sl_x += subsample_width){
        for (sl_y = ll_y; sl_y <= ur_y; sl_y += subsample_width){
            [j_x, j_y] =  jitter(s_x, s_y); // Compute noise for sample
            [s_x, s_y] =  [sl_x, sl_y] + [j_x, j_y]; //	Add noise
            if(sample_test(poly, s_x, s_y)){
                process_fragment(poly, s_x, s_y);}}}}

int sample_test(poly, s_x, s_y){

    // Shift vertices such that sample is origin
    v0_x = poly.v[0].x - s_x;
    v0_y = poly.v[0].y - s_y; 
    v1_x = poly.v[1].x - s_x;
    v1_y = poly.v[1].y - s_y; 
    v2_x = poly.v[2].x - s_x;
    v2_y = poly.v[2].y - s_y;

    // Distance of origin shifted edge
    dist0 = v0_x * v1_y	- v1_x * v0_y; // 0-1 edge 
    dist1 = v1_x * v2_y	- v2_x * v1_y; // 1-2 edge 
    dist2 = v2_x * v0_y - v0_x * v2_y; // 2-0 edge
    
    // Test if origin is on right side of shifted edge
    b0 = dist0 <= 0.0; 
    b1 = dist1 <  0.0; 
    b2 = dist2 <= 0.0;
    
    // Triangle min terms with no culling
    //triRes = (b0 && b1 && b2) || (!b0 && !b1 && !b2);
    
    // Triangle min terms with backface culling
    triRes = b0 && bl && b2;

    return(triRes); 
}
``` 
