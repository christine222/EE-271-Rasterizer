# Introduction

For the EE271 class project you are going to work on a micropolygon rasterization unit. If you have no idea of what a micropolygon or rasterization is, don't panic (yet). We will explain both of these terms in the document, and in a review session we have scheduled for the class. Right now all you need to know is that this is one of the current trends in computer graphics. Unfortunately, this trend does not work well with a conventional graphics processor (GPU), so it is a good target for hardware acceleration.

We tried to construct this project in stages so that you will get to perform several kinds of tasks that you might be asked to do in industry. You will first start by finishing a C++ gold model for this design. Once this is completed, we hope you will have a better understanding of what the logic is supposed to do. Next, you will implement a missing module in RTL, synthesize it, and try to modify it to make it work better.

When you come to make RTL modifications, you will notice that the design is implemented using SystemVerilog. SystemVerilog's parameters and `generate` blocks enables designers to create design generators, or constructors, instead of design instances. 
We use this because we want you to parameterize your design, and procedurally encode your solution  as a generator. This will help you explore more design alternatives, achieve better optimizations, and generally be a much more productive designer.

Finally, you will try a bunch of optimization choices in order to largely improve performance or save energy (or both). It should be fun. We hope you enjoy doing it as much as we enjoyed creating it.

This document will serve as an overview of the project. Please read the entire description first and only then start working. 
