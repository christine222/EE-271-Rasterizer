#!/bin/bash
FILES_GOLD=gold/* 
FILES_RTL=rtl/*

cd ../
rm -rf rasterizer_distrib
cp -rf rasterizer rasterizer_distrib
cd rasterizer_distrib
rm -rf .git
rm .gitignore

for f in $FILES_GOLD
do
  echo "Processing $f"
  awk -f proc.awk $f > tmp && mv tmp "$f"
done

for f in $FILES_RTL
do
  echo "Processing $f"
  awk -f proc.awk $f > tmp && mv tmp "$f"
done

cd ../
tar -zcvf rast_dist.tar.gz rasterizer_distrib/
rm rasterizer/rast_dist.tar.gz
cp -f rast_dist.tar.gz rasterizer/
rm -rf rasterizer_distrib/