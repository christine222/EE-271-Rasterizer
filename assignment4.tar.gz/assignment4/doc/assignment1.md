## Assignment 1

In the first assignment, you are asked to finish the gold model for the design. As you may recall from lecture, the gold model is a model for the functionality of the design absent of many of the details that make it hardware implementable. The purpose of this exercise is for you to become more familiar with how the overall algorithm works and better understand the initial design.

In the next assignment, we will use this code as part of our testbench to check the functionality of our RTL design.

### Instructions

To get started, load the EE271 setup script [`setup_ee271.cshrc`](../setup_ee271.cshrc).

For this assignment, you will need to fill in C code for the BBox and Sample Test functions.

The file is located at [`gold/rasterizer.c`](../gold/rasterizer.c). Look for the comments "// START CODE HERE" and "// END CODE HERE".

* There are some comments in the file, but the pseudo code should be your main reference. Keep in mind that it is all in fixed point.

* Once you are satisfied with your addition, compile from assignment1 directory:

    ```
    make clean comp_gold
    ```

* To run the gold model with a test vector:

    ```
    ./rasterizer_gold out.ppm $EE271_VECT/vec_271_01_sv.dat
    ```

* To compare the output with the corresponding reference image:

    ```
    diff out.ppm $EE271_VECT/vec_271_01_sv_ref.ppm
    ```
Note: No output means that the files match.

* The output can be viewed with (not necessary but possibly useful):

    ```
    display out.ppm &
    ```

* To compare the output with the reference image in MATLAB (not necessary but possibly useful):
 * Start MATLAB:

    ```
    matlab
    ```
 * Then the following commands should execute in MATLAB command line:

    ```
    >A = imread(’output.ppm’);
    >B = imread(’/path/to/reference.ppm`);
    >C = abs(A - B);
    >find(C) $ this shows positions of non-zero values in matrix C
    >imshow(C*255) $ this shows a image of matrix C
    ```

* There are some other test vectors and reference images in your `$EE271_VECT` folder which you should try in order to test your code.

### Submission

In this assignment, you need to submit the project folder containing code of the C gold model, which should be able to pass all the test vectors. The folder you wish to submit should be called: `assignment1`

Clean up the folder with the command:

```
make cleanall
```
The folder `assignment1` should contain an extra file: `names.txt`. The file `names.txt` should contain 6 lines: the first student's SUID on the first line, first student's name on the second line, first student's email on the third line, second student's SUID on the fourth line, second student's name on the fifth line, and second student's email on the sixth line. For example:

00001111

Olivier Jin

ojin@stanford.edu 

00001112

Zelin Zhang

zelinzh@stanford.edu

You should tar ball this directory with the command:
```
tar -czvf assignment1.tar.gz assignment1
```

You can also test your submission with the command:
```
./grading_ass1.pl assignment1.tar.gz
```

This is more or less the script we will use to evaluate your submissions. If the script fails while processing your submission you may have misformatted your submission. Submit your assignment1.tar.gz on Gradescope.

The DUE DATE of this assignment is Monday, November 11

ONLY ONE SUBMISSION is needed for a group of two students.
