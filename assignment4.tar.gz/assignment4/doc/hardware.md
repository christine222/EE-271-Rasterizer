# Hardware Overview

Figure 12 is an overview of the hardware. With respect to the [pseudo code](https://github.com/priyanka-raina/rasterizer/blob/master/doc/rasterization.md#pseudo-code): 

* BBox stage corresponds to the generation of a clamped axis aligned bounding box (implemented in [`rtl/bbox.sv`](../rtl/bbox.sv)).
* Iterator stage is a finite state machine (FSM) correcponding to the set of nested for loops which iterate all the sub-pixel positions in the bounding box ([`rtl/test_iterator.sv`](../rtl/test_iterator.sv)).
* Hash box corresponds to the jitter function to add random noise to the sample position ([`rtl/hash_jtree.sv`](../rtl/hash_jtree.sv)).
* Sample Test box corresponds to the sample test function inside the nested for loops ([`rtl/sampletest.sv`](../rtl/sampletest.sv)).

![Hardware Pipeline](img/figure12.png)

Figure 12: Hardware Pipeline

In addition, Figure 12 also implies the default timing for this pipeline: there are three pipeline stages in BBox, one stage in Iterator, two in Hash, and two in Sample Test. 
The good news is that all the pipeline depths of these blocks (except the Iterator) are coded as SystemVerilog parameters, so you can easily change the numbers when optimizing the design. 
The the depth of Iterator is fixed at one since it is an FSM. Besides, the signals in this figure (the gray dotted lines) are labeled with a pipe stage number. As a convention, the data enters the raster block at pipe-stage 10.

More details of the function blocks will be discussed in the following parts of this section.
 
## [`rtl/bbox.sv`](../rtl/bbox.sv)

* **Inputs:**
    * 3 or 4 x, y vertices corresponding to ploy (tri, quad)   
    * 3 signals corresponding to color (RGB) values of the poly 
    * 1 signal indicating whether quad or tri
    * 1 valid bit, indicating input poly is valid
   
* **Controls:**
    * 1 halt signal indicating that no work should be done 
    * 2 x, y vertices indicating screen dimensions
    * 1 four bit vector indicating the degree of supersampling required for the final image. The valid values are one hot.
        * 4'b1000  :   lx MSAA
        * 4'b0100  :   4x MSAA
        * 4'b0010  :  16x MSAA
        * 4'b0001  :  64x MSAA
      
* **Outputs:**
    * 2 vertices describing a clamped bounding box
    * 1 valid signal indicating that bounding box value is valid
    * Signals propagating useful information about poly (color and tri/quad bit)
   
* **Function:**
    * Determine a bounding box for the polygon represented by the vertices. Clamp the bounding box to the sub sample pixel space.
    * Clip the bounding box to screen space.
    * Halt operating but retain values if next stage is busy.
   
* **Long Description:**
    * This bounding box block accepts a micropolygon described by three/four vertices and determines a set of sample points to test  against the micropolygon. These sample points correspond to the sub-pixel fragments that compose the pixel, since multi-sample anti-aliasing (MSAA) is enabled. The clamped bounding box was chosen as the description for the set of samples to test as it is concise and it  is easy to calculate.
    * The bounding box can be determined through calculating the maximum and minimum for x and y to generate a lower left vertices and upper right vertices. Next, the bounding box needs to be clamped to the fragment grid. This can be accomplished through rounding the bounding box values to the fragment grid. Additionally, any sample points that exist outside of screen space should be rejected. So the bounding box can be clipped to the visible screen space. This clipping is done using the screen signal, by limiting the bounding box dimensions to the screen dimensions.
    * The halt signal is used to hold the current polygon bounding box. The reason is that only one sample can be tested per cycle. As a bounding box can hold multiple samples, the box data must be held while the samples in the box are iterated over. The halt signal is also required for when the write device, which is located down the pipeline, is full/busy.
    * The valid signal is used to indicate whether or not a micropolygon is actually available. This can be useful if the device being read from, has no more micropolygons, or if a bounding box exists entirely off-screen.

## [`rtl/test_iterator.sv`](../rtl/test_iterator.sv)

* **Inputs:**
   * Bounding box and micropolygon information

* **Controls:**
   * 1 four bit vector indicating the degree of supersampling

* **Outputs:**
   * Subsample location and micropolygon information
   * 1 halt signal indicating that previous stages of pipeline should be halt
   
* **Function:**
   * Iterate from left to right and bottom to top across the bounding box.
   * While iterating set the halt signal in order to hold the bounding box pipeline in place.
   
* **Long Description:**
   * The iterator starts in the waiting state. When a valid micropolygon bounding box appears at the input, the iterator will enter the testing state the next cycle. The first sample is equivalent to the lower left coordinate of the bounding box.
   * While in the testing state, the next sample for each cycle should be one sample interval to the right, except when the current sample is at the right  edge. If the current sample is at the right edge, the next sample should be one row up and all the way to the left. Additionally, if the current sample is on the top row and the right edge, the next cycles sample should be invalid and equivalent to the  lower left vertices. In this case, the iterators next state should be waiting.

## [`rtl/hash_jtree.sv`](../rtl/hash_jtree.sv)

* **Inputs:**
   * Sample coordinates and micropolygon information

* **Controls:**
   * 1 four bit vector indicating the degree of supersampling

* **Outputs:**
   * Jittered sample coordinates and micropolygon information

* **Function:**
   * Calculate an x displacement and y displacement distributed over the sample area adding small noises in order to prevent Moir pattern. The hash function calculates this displacement using an XOR tree that takes the sample coordinates as inputs.

## [`rtl/sampletest.sv`](../rtl/sampletest.sv)
* Samples are tested

* **Inputs:**
   * Sample and micropolygon information

* **Outputs:**
   * Subsample hit flag, subsample location, and micropolygon information
   
* **Function:**
   * Using edge equations determine whether the sample location lies inside the micropolygon. In the simple case of the triangle, this  will occur when the sample lies to one side of all three lines (either all left or all right). Additionally, if backface culling is performed, then only keep the case of all right. This is arbitrarily determined by the tessellation unit that appears much earlier in the pipeline. Currently, the behavior is to back-face cull. This behavior can be changed by altering the logic after distance evaluation.
   * This block evaluates the three edges described by the micropolygons vertices, to determine which side of the lines the sample point lies. Then it determines if the sample point lies in the micropolygon by and'ing the result of the three distance evaluations.
   * Edge equation:
      * For an edge defined as traveling from the vertices `(x1, y1)` to `(x2, y2)`, the sample `(xs, ys)` lies to the right of the line if the following expression is true:
      * `0  > (x2 - x1)(ys - yl) - (xs	- x1)(y2 - yl)`
      * Otherwise the sample lies on the line (exactly 0) or to the left of the line.

## Signals

Most signals have a suffix of the form `_Rxx:N` where R indicates that it is a Raster Block signal, xx indicates the clock slice that it belongs to and N indicates the type of signal that it is. H indicates logic high, L indicates logic low, U indicates unsigned fixed point, and S indicates signed fixed point.

Here is a list of common signals in the Raster pipeline.

* `poly_RxxS`: 3 sets of X,Y,Z signed fixed Point values
* `color_RxxS`: An RGB vector describing the color of the micropolygon
* `isQuad_RxxH`: A flag indicating that the micropolygon is a quad
* `validPoly _RxxH`: A valid data flag for the micropolygon
* `halt_RnnL`: Flag that indicates no work should be done
* `screen _RnnS`: Designates the width and height of the screen
* `subSample_RnnU`: Designates the level of super sampling
* `clk`: Clock
* `rst`: Reset
* `box_RxxS`: 2 sets X,Y fixed point values
* `sample_RxxS`: A sample location to be tested, 1 set X,Y fixed point values
* `validSamp_RxxH`: The sample is valid to be tested
* `hit_valid_RxxH`: Flag indicating if sample lies inside the micropolygon
