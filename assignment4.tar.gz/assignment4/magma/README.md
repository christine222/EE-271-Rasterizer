# Genesis to magma porting progress

## Issues
* Halt right after reset in iterator is not 1.

## Design modules

| Genesis file | Magma file | Translated? | Unit tested? |
|-|-|-|-|
|[`bbox.vp`](../rtl/bbox.vp)|[`bbox.py`](bbox.py)|Yes|Yes|
|[`test_iterator.vp`](../rtl/test_iterator.vp)|[`iterator.py`](iterator.py)|Yes|Yes|
|[`sampletest.vp`](../rtl/sampletest.vp)|[`sampletest.py`](sampletest.py)|Yes|Yes|
|[`rast.vp`](../rtl/rast.vp)|[`rast.py`](rast.py)|Yes||
|[`dff.vp`](../rtl/dff.vp)|[`dff.py`](dff.py)|Yes|-|
|[`dff2.vp`](../rtl/dff2.vp)|[`dff.py`](dff.py)|Yes|-|
|[`dff3.vp`](../rtl/dff3.vp)|[`dff.py`](dff.py)|Yes|-|
|[`hash_jtree.vp`](../rtl/hash_jtree.vp)|[`hash_jtree.py`](hash_jtree.py)|Yes|Yes|
|[`tree_hash.vp`](../rtl/tree_hash.vp)|[`tree_hash.py`](tree_hash.py)|Yes|Yes|

## Test modules
| Genesis file | Magma file | Translated? | Unit tested? |
|-|-|-|-|
|[`bbx2trsl_monitor.vp`](../rtl/dff.vp)|||
|[`bbx_sb.vp`](../rtl/dff.vp)|||
|[`clocker.vp`](../rtl/dff.vp)|||
|[`gm2rst_monitor.vp`](../rtl/dff.vp)|||
|[`perf_monitor.vp`](../rtl/dff.vp)|||
|[`rast_driver.vp`](../rtl/dff.vp)|||
|[`rst2zbuff_monitor.vp`](../rtl/dff.vp)|||
|[`smpl_cnt_sb.vp`](../rtl/dff.vp)|||
|[`smpl_sb.vp`](../rtl/dff.vp)|||
|[`testbench.vp`](../rtl/dff.vp)|||
|[`top_rast.vp`](../rtl/dff.vp)|||
|[`trsl2smpl_monitor.vp`](../rtl/dff.vp)|||
|[`zbuff.vp`](../rtl/dff.vp)|||

# Things to keep in mind when designing in Magma
- The default mode for DFF and Registers are a synchronous reset if reset is high. You can change that to an asynchronous reset by using has_async_reset=True.
- When you do bit selection, you specify the LSB first, for example, signal[low:high] instead of signal[high:low] like in verilog. 
- Use print(type(object)) to print the type of object.
- To print definition of combinational use `print(repr(io.get_next_state.circuit_definition))` for example if your combinational function is called `get_next_state`.
