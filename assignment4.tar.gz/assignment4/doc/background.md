# Background

This section provides the preliminary information required to understand the project. First, we review a number of topics that you should  already  be familiar with to make sure we are all on the same page. Second, we present three computer graphics topics to help you understand the context of the project. Finally, a section on fixed point arithmetic is provided since it is an essential part of the project's implementation.

## What You Should Know
The project will require some level of experience with SystemVerilog and C/C++. In this project, we will also introduce a new language called Genesis2, which is a meta-programming language for building chip generators. Here are some useful references on these topics:

* **SystemVerilog**:  
   * [Verilog Tutorial](http://www.doulos.com/knowhow/verilog_designers_guide/)
   * [SystemVerilog Tutorial](http://www.doulos.com/knowhow/sysverilog/tutorial/)
      * [SystemVerilog Assertions Tutorial](http://www.doulos.com/knowhow/sysverilog/tutorial/assertions/)
      * [SystemVerilog DPI Tutorial](http://www.doulos.com/knowhow/sysverilog/tutorial/dpi/)
   * Books
      * [SystemVerilog For Design](http://www.springerlink.com/content/w134858r71387n5h/)
      * [SystemVerilog For Verification](http://www.springerlink.com/content/x71knj/)
         * [Interfacing with C](http://www.springerlink.com/content/j703h3nj43498410/?p=67a54fc6ae7f4195b6def6f1196cbad6&pi=11)
         * [Writing Testbenches using SystemVerilog](http://www.springerlink.com/content/kv2481/)
       
* **Genesis2**: Genesis2 is a meta-programming system. In this project, you will learn how to use Genesis2 to write a chip generator rather than a fixed logic design in plain Verilog. We use Genesis2 for everything related to the elaboration of the design. That includes design parameters, procedural Verilog code generation, introspection and more. In particular, all RTL and testbench code for this project is written using Genesis2.

    Genesis2 provides hardware designers with a rich software language for writing instructions that specify how to generate modules from a set of input parameters. These instructions can be seen as an explicit "elaboration program" or as an object-oriented constructor for generating elaborated instances. The behavioral description, however, remains in SystemVerilog. Granted, in software coding, the semantics of coding a constructor for a class is the same as the semantics of coding the rest of that class's functionality. In contrast, the description of the functionality of a hardware module must obey strict rules of synthesizability. This historically resulted in HDLs that  enforced strict rules on the construction of the system, also known as its elaboration. With Genesis2, we remove this artificial limitation, by allowing the designer to code in two languages simultaneously and interleaved: one that describes the hardware proper (SystemVerilog), and one that decides what hardware to use for a given instance (Perl). However, Genesis2 maintains the notion of modules,  hierarchy and system, by forcing the two language layers to share the same scopes.
When you look at our code, or write your own, lines that start with `//;` are Perl lines and use strictly Perl syntax. Lines that have \`expression\` (an expression between two back-ticks) is Verilog with an inlined Perl expression. At the meta-layer, Genesis2 provides a number of built-in parametrization, generation and introspection methods. This is described in the documentation wiki page at the link below.

    * [Genesis2 User Guide](http://genesis2.stanford.edu/mediawiki/index.php/Genesis2)
    * [(DAC2012 paper) Avoiding game over: bringing design to the next level](http://dl.acm.org/citation.cfm?id=2228472&preflayout=tabs)
        
* **Perl**: In Genesis2, we use Perl to manipulate the generation of SystemVerilog code. Therefore you will need to be able to read and manipulate some lightweight Perl code. Here are some references that will help you if you are not already familiar with Perl. **Note: One  can write really perlish (un-readable) code in Perl. That type of code is more concise but really bad for collaborative projects. Make  sure your code is readable and well commented.**
   * Perl online documentation: [Perldoc](http://perldoc.perl.org/index.html)
   * Introduction to Perl: [Essential Perl](http://cslibrary.stanford.edu/108/EssentialPerl.html)
   
* **C/C++**: C++ code will be used to implement the golden model in assignment one. C++ is very similar to C. Some of the major features implemented in C++ are:
   * Pass By Reference
      * [A Word on References](http://www.cplusplus.com/doc/tutorial/functions2/)
   * Standard Template Library (STL)
      * [An Introduction](http://www.sgi.com/tech/stl/stl_introduction.html)
   * Templates
      * [An Explanation](http://www.cplusplus.com/doc/tutorial/templates/)
 
## The Modern Real-Time Computer Graphics Pipeline

![Computer Graphics Pipeline](img/graphics_pipeline.png)

Figure 1: Computer Graphics Pipeline

Computer graphics can be described as the problem of converting 1's and O's into a two dimensional array of pixels. This covers every image you see on a computer display, including font rendering, flight simulators, interface design, CAD, computer generated movies, and video games.

The real-time computer graphics problem adds an additional constraint to the general computer graphics problem. The real time constraint is that the processing of data visualization be fast enough to be imperceptible to the user. In most cases, this means sustaining a frame rate - the speed that the image on the screen is replaced - of 60Hz. In graphics intensive applications like flight simulators, architectural simulators, CAD, and video games, this often means performing significant amounts of computation very quickly.

While some applications can afford to do most of the graphics work entirely on the central processing unit (CPU), most high-end applications require specialized hardware in the form of a graphics processing unit (GPU).

To achieve high speed, graphics operations are broken into different pipeline stages. At the highest level of abstraction, the real-time graphics pipeline, shown in Figure 1, can be broken into three parts: application, geometry, and rasterization.

For this discussion, we can assume that the application portion takes the objects that need to be drawn on the screen and generates their positions and geometries in the 3-D space. The resulting data could consist of basic shapes (easy for hardware to render), like spheres, cones, or arbitrary 3-D objects; in general, however, it is best thought of as surfaces in 3-D space each represented by meshes composed of triangles (and quadrilaterals - polygons in general). An example is shown in Figure 2, where the upper left and lower right quadrant show a wire mesh demonstrating the geometric description of the bird.

![Bird Mesh](img/blender.jpg)

Figure 2: Bird Mesh (Blender Foundation)

Next, the geometry portion of the pipeline applies many kinds of transformations to these mesh data (3-D vertices of every triangle) and generates their proper positions on the screen (2-D space). Finally, the rasterization portion converts the 2-D vector data of triangles to raster format, corresponding to pixels on the screen and uses it to fill in an image.

### Geometry Pipeline

While this project does not directly touch the geometry pipeline, this section will give you a brief background, to provide context to the later discussion about rasterization. The geometry pipeline can be broken into five parts:

* Model Transform
* Vertex Shading
* Projection
* Clipping
* Screen Mapping

**Model Transform:** The data provided by the application may not explicitly specify the location and scale of each triangle and quadrilateral in the space, which is the space of the scene being drawn. For example, a squadron of C-130 aircraft may be defined compactly in terms of one 1:16 C-130 model. The application might provide one 1:16 C-130 model, the position, and the orientation of each plane. The model would then need to be instanced 5 times, scaled 16x to match the environment of the simulation, and rotated appropriately. The model transform block of the pipeline takes all of the relative definitions and transforms them into triangles and quadrilaterals that appear in the world.

**Vertex Shading:** Vertex shading refers to altering the data associated with the vertices that define the triangles and quadrilaterals in a scene. For example the vertex shader may want to alter the color of the vertices, or even displace them to generate some effect like waves on the ocean.

**Projection:** The projection portion of the pipeline performs an additional transformation on the scene data. While the geometric data defined in world space contains information about the absolute location of the vertices, we want to know what to draw on a 2-D screen. We can determine this information by placing a virtual camera at where our eye should be. The projection portion transforms all of the data such that  things far away from the camera will appear smaller and things close-up will appear larger. The projection portion also does the work of rejecting data that doesn't fit inside the view space of the camera, for example something behind the camera. A more formal explanation for the work done in the projection portion would be that it converts all of the geometry located in the viewing frustum and transforms it such that the frustum becomes a unit cube. A view frustum is shown in Figure 3. The geometry produced by this portion of the pipeline is therefore defined inside a cube with sides of length 1.

![View Frustum](https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/ViewFrustum.svg/525px-ViewFrustum.svg.png)

Figure 3: View Frustum (Wikipedia)

**Screen Mapping:** The screen mapping portion of the pipeline takes this view space data and maps it to the pixels in the screen. This would mean transforming the cube and the geometry inside it such that one face of the cube matches the size of the image to be colored. Once the  geometric data has been mapped to the screen it can be colored.
 
### Rasterization

Rasterization is the essence of this class project. The purpose of this section is to give you the "what?" and "why?" (the "how?" is discussed later). The rasterization pipeline can be broken into four parts:

* Triangle Setup
* Triangle Traversal
* Pixel Shading
* Merging

**Triangle Setup:** The triangle setup stage encompasses all of the work done to prepare for traversing the polygon. This could include calculating the slopes of edges or whether the polygon is occluded.

**Triangle Traversal:** The triangle traversal stage determines which pixels lay inside a polygon. In old pipelines this was done with scan algorithms that would traverse the polygon from left to right and top to bottom, testing each pixel to see whether or not it lies inside a polygon. In modern pipeline the work is done hierarchically using a few tests to determine whether or not large numbers of pixels lie inside a polygon.

A trivial algorithm for triangles would test four non-adjacent pixels. If all four pixels fell inside the triangle then all pixels bounded by those four pixels are inside the triangle. These types of hierarchical tests take advantage of pixel coherence, the idea that neighboring pixels are likely to lie in the same polygon. However, as computer graphics advance, triangles become smaller and smaller (and hence the term 'micro-polygons'). This means that neither the old scan nor the hierarchical algorithm is efficient. This is where you come into play (you'll see how next).

**Pixel Shading:** Pixel shading is the stage of the pipeline where a pixel is given a color based on the polygon it falls into. In the case of flat shading, where a polygon has a solid color, the pixel color is simply assigned the polygon's color. In more complicated forms of shading, lighting calculations are used to determine the color based on the orientation of the polygon with respect to all of the light sources in the scene. It is also possible to texture a polygon. Texturing a polygon refers to the application of an image to the surface of a polygon. Texturing would allow you to make a brick wall by simply generating a quadrilateral and then applying the picture of the wall to the quadrilateral. An example of a textured mesh is given in Figure 4. The image on the left shows the application of a checkered  pattern to the mesh while the right image shows a two-dimensional image with an outline of the polygons in the mesh. One could color this two dimensional image of the alien goat skin and then apply it to the alien goat.

![Alien Goat Texturing](img/goat.png)

Figure 4: Alien Goat Texturing (Blender Foundation)

**Merging:** Finally, these pixels need to be aggregated to form the final image. In the process of mapping many triangles to the screen, however, there is a possibility that we may have mapped an occluded triangle to the same pixel as the occluding triangle. During merging, if the occluding triangle is defined as opaque, the occluded triangle's pixel is rejected; otherwise, the occluded triangle's pixel is mixed with the occluding triangle. The image is complete after all of the pixels have been aggregated.

### More Information

* [Real Time Rendering](http://www.realtimerendering.com/) is a useful [text](http://www.amazon.com/Real-Time-Rendering-Tomas-MOller/dp/1568814240?tag=realtimerenderin) that describes the computer graphics pipeline and many modern rendering techniques. Their [blog](http://www.realtimerendering.com/blog/) can also be very informative. Stanford students can view this text on-line through the library [here](http://library.books24x7.com/toc.asp?site=IYC7R&bookid=31068).

* [OpenGL Programming Guide](http://proquest.safaribooksonline.com/9780321669292) is a useful reference for the OpenGL interface. Its [introduction](http://proquest.safaribooksonline.com/9780321669292/ch01?imagepage=1#X2ludGVybmFsX1ByaW50RmlkZWxpdHk/eG1saWQ9OTc4MDMyMTY2OTI5Mi9jaDAxbGV2MXNlYzUmaW1hZ2VwYWdlPTEw) contains a summary of the OpenGL rendering pipeline. This book is available to all Stanford students free at [O'Reilly's Safari](http://proquest.safaribooksonline.com/).

* [Computer Graphics and Geometric Modeling](http://www.springerlink.com/content/r18675/?p=53045b6066ff42989ac40e0c87d9433a&pi=16) contains a more in-depth discussion of the components of the computer graphics pipeline.

## Multisample Anti-Aliasing

As many will recall from discussions in signal processing, sampling a signal below the Nyquist sampling rate will introduce aliasing into the sampled signal. In computer graphics, aliasing is observed in the artifacts that occur along sloped edges in images called jaggies. The character "A" on the left of Figure 5 shows an example of aliasing. Additionally, in an animated scene, aliasing will cause polygons to look like they are stuttering across the scene as they jump from pixel to pixel. Jaggies and stuttering are undesirable and decrease the overall quality of an image and animation.

A solution to this problem is to sample the image at a higher rate to reduce the aliasing error. In computer graphics, Full Screen Anti-Aliasing (FSAA) can be thought of as generating a high resolution image and then averaging it down to a lower resolution picture. The pixels in the high resolution image are referred to as fragments which are averaged into the pixels in our final image. The character "A" on the right of Figure 5 shows an example of anti-aliasing. Multi-sample Anti-Aliasing (MSAA) is similar to FSAA, but requires less storage and computation to generate the final image. Our micropolygon rasterization pipeline implements varying degrees of MSAA, so you should be comfortable with the idea that we will rasterize fragments which will later be averaged into a pixel.

![Aliasing of A](https://upload.wikimedia.org/wikipedia/commons/8/88/Aliasing_a.png)

Figure 5: Aliasing of A (Wikipedia)

## Micropolygon Rendering

One concern in computer graphics is the generation of highly realistic and highly stylized images. One problem with modern pipelines is that while many tricks can be played, when an image is composed of too few polygons it can take on an undesirably faceted appearance. Early video games and CAD applications are memorable for their flat and faceted appearance.

A [solution](http://portal.acm.org/citation.cfm?id=37401.37414&coll=ACM&dl=ACM&CFID=51562846&CFTOKEN=61398239) proposed long ago by PIXAR, and used in films like Wall-E and Toy Story, is the use of micropolygons. A micropolygon avoids the problem of faceting by occupying a very small area - the area of half a pixel. The algorithm was referred to as the [Reyes Image Rendering Architecture](http://en.wikipedia.org/wiki/Reyes_rendering). The part of the pipeline that we are concerned with in this project is the hide stage. We will use hide and micropolygon rasterization interchangeably. Before the hide stage the micropolygons have already been positioned in screen space and shaded, as opposed to modern pipelines where fragments are shaded. Then, during the hide stage, the micropolygons are sampled to determine the color of the fragments that correspond to the micropolygons. Generally, the hide stage can be broken into two steps: determining which fragments should be tested against a micropolygon and testing those fragments against the micropolygon to determine if they lie inside.

While Pixar hoped to achieve memorable movies, the goal in our project is to achieve Toy Story like rendering in real-time using the specialized hardware. The hardware design in this project is based on the software implementation presented in this [document](http://graphics.stanford.edu/papers/mprast/). This hardware represents a variation on the design and concepts presented in this [paper](http://graphics.stanford.edu/papers/hwrast/). The major difference between micropolygon rasterization and modern rasterization is that hierarchical approaches are no longer efficient, as it is difficult to find large numbers  of fragments that are trivially inside a small polygon.

## Fixed Point Arithmetic

With your experience in computer programming you have already encountered two traditional data types used to represent numbers. These data types are integer and floating point numbers. The interesting tradeoff from the perspective of micropolygon rasterization is that integer computation is fast while floating point numbers represent fractional numbers well. Unfortunately, floating point computation is more complex which makes it high power and slow when compared to integers. As a compromise, we could pick some constant position in the integer to represent the decimal. In this way everything to the left of this decimal is the integer portion and everything to the right is the fractional portion. This representation is referred to as fixed point notation.

Fixed point operations are generally the same as integer operations. Comparisons, additions, and subtractions are all implemented in the same manner as traditional integer operations. The one exception is multiplication which requires shifting the result to the correct position, as you will recall from your childhood introduction to the multiplication of decimal numbers.

The implementation of the micropolygon hider that you will be working with utilizes a fixed point representation and fixed point operations. You should be comfortable with the idea that the values represented in the RTL may have a data type of integer but actually represent a fixed point notation.
