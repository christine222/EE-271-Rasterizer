To compile this documentation into a pdf use [pandoc](https://pandoc.org):
```
pandoc introduction.md background.md rasterization.md hardware.md assignments.md assignment1.md assignment2.md assignment3.md appendix.md --variable urlcolor=blue --pdf-engine=xelatex -o rasterizer.pdf --toc
```
