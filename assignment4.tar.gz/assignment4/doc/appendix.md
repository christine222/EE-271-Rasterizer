# Appendices

## Rasterization for Quadrilaterals (Triangle-Pairs) 

### Sample Test Algorithm

The triangle-pair case is a little more complicated, but there is an advantage to allowing triangle-pairs into the pipeline. To a first degree, rasterizing a triangle-pair is a lot like rasterizing two triangles at once. A better explanation is that the bounding box is a tighter bound on the pair than on the singleton. This tighter bound means that the ratio of sample hits to misses is higher. This higher ratio is desirable as it increases the pipeline's microp-olygon throughput.

The representation for these pairs is slightly different than for a single triangle. For triangle pairs the shared edge is assumed to be from the second vertex to the fourth vertex. These complications generate a set of min-terms as opposed to the single min-term for the triangle test. However these terms reduce to an expression representing the case when a sample is in one triangle or the other.

From the psuedocode in the following section you can see that there are a total of 10 cases where the sample in quadrilateral test is a hit. The following list enumerates those cases and gives an example for each one. Note that in these cases `b0` represents the test for the sample point being right of edge 0, `b1` edge 1, `b2` edge 2 and so on and is consistent with the psuedocode given on the next page. The green edge corresponds to the fourth edge from the first to third vertices whose sample right of edge test result is `b4`.

* `(!b4 && !b3 && !b2 && b1 && !b0)` given in Figure 14

    ![Sample Case 1](img/figure14.png)

    Figure 14: Sample Case 1
 
* `(!b4 && !b3 && b2 && !b1 && !b0)` given in Figure 15

    ![Sample Case 2](img/figure15.png)

    Figure 15: Sample Case 2

* `(!b4 && !b3 && b2 && b1 && b0)` given in Figure 16

    ![Sample Case 3](img/figure16.png)

    Figure 16: Sample Case 3

* `(!b4 && b3 && b2 && b1 && !b0)` given in Figure 17

    ![Sample Case 4](img/figure17.png)

    Figure 17: Sample Case 4

* `(!b4 && b3 && b2 && b1 && b0)` given in Figure 18

    ![Sample Case 5](img/figure18.png)

    Figure 18: Sample Case 5

* `(b4 && !b3 && !b2 && !b1 && b0)` given in Figure 19

    ![Sample Case 6](img/figure19.png)

    Figure 19: Sample Case 6

* `(b4 && b3 && !b2 && !b1 && !b0)` given in Figure 20

    ![Sample Case 7](img/figure20.png)

    Figure 20: Sample Case 7

* `(b4 && b3 && !b2 && b1 && b0)` given in Figure 21

    ![Sample Case 8](img/figure21.png)

    Figure 21: Sample Case 8

* `(b4 && b3 && b2 && !b1 && b0)` given in Figure 22

    ![Sample Case 9](img/figure22.png)

    Figure 22: Sample Case 9

* `(b4 && b3 && b2 && b1 && b0)` given in Figure 23

    ![Sample Case 10](img/figure23.png)

    Figure 23: Sample Case 10

### Pseudo Code
Pseudo code for micropolygon rasterization supporting either triangle singletons or triangle pairs:

```
void rast(vector<u_Poly> polys){
    for(i = 0; i < polys.size(); i++){
        rast_upoly(polys[i]); 
    }
}
        
inline void rast_upoly(poly) {
    // Calculate clamped bounding box
    ll_x = FLOOR_SS(MIN( x coordinate of poly vertices )); // Min X rounded down to subsample grid 
    ur_x = FLOOR_SS(MAX( y coordinate of poly vertices )); // Max X rounded down to subsample grid 
    ll_y = FLOOR_SS(MIN( x coordinate of poly vertices )); // Min Y rounded down to subsample grid 
    ur_y = FLOOR_SS(MAX( y coordinate of poly vertices )); // Max Y rounded down to subsample grid

    // Clip bounding box to visible screen space
    ur_x = ur_x > screen_width ? screen_width : ur_x; 
    ur_y = ur_y > screen_height ? screen_height : ur_y; 
    ll_x = ll_x < 0 ? 0 : ll_x; 
    ll_y = ll_y < 0 ? 0 : ll_y;
    
    // Iterate over samples, test if in micro polygon
    // Note that offscreen bounding boxes are rejected by for loop test
    for(s_x = ll_x; s_x <= ur_x; s_x += subsample_width){
        for(s_y = ll_y; s_y <= ur_y; s_y += subsample_width){ 
            [j_x, j_y] = jitter(s_x, s_y); // Noise for sample 
            if(sample_test(poly, s_x + j_x, s_y + j_y)){
                process_fragment(poly, s_x, s_y);
            }
        }
    }
}
                
inline int sample_test(poly, s_x , s_y){
    q = poly.vertices == 4 ; // Is polygon a quadrilateral
    
    // Shift vertices such that sample is origin
    v0_x = poly.v[0].x − s_x; 
    v0_y = poly.v[0].y − s_y; 
    v1_x = poly.v[1].x − s_x; 
    v1_y = poly.v[1].y − s_y; 
    v2_x = poly.v[2].x − s_x; 
    v2_y = poly.v[2].y − s_y; 
    v3_x = poly.v[3].x − s_x; 
    v3_y = poly.v[3].y − s_y;

    // Distance of origin shifted edge
    dist0 = v0_x * v1_y − v1_x * v0_y; // 0-1 edge
    dist1 = v1_x * v2_y − v2_x * v1_y; // 1-2 edge
    dist2 = v2_x * v3_y − v3_x * v2_y; // 2-3 edge
    dist3 = v3_x * v0_y − v0_x * v3_y; // 3-0 edge
    dist4 = v1_x * v3_y − v3_x * v1_y; // 1-3 edge
    dist5 = v2_x * v0_y − v0_x * v2_y; // 2-0 edge
    
    // Test if origin is on right side of shifted edge
    b0 = dist0 <= 0.0;
    b1 = dist1 <  0.0;
    b2 = dist2 <  0.0;
    b3 = dist3 <= 0.0;
    b4 = dist4 <  0.0;
    b5 = dist5 <= 0.0;
    
    // Triangle min terms with no culling
    //triRes = (b0 && b1 && b2) || (!b0 && !b1 && !b2);
    
    // Triangle min terms with backface culling
    triRes = b0 && b1 && b5;
    
    // Quad min terms with back face culling 
    // Can be implemented as a look up table
    quadRes = ( b1 &&  b2 && !b4 && (b0 ||  b3))
           || (!b1 && !b2 &&  b4 && (b0 xor b3)) 
           || ( b0 &&  b3 &&  b4 && (b1 ||  b2))
           || (!b0 && !b3 && !b4 && (b1 xor b2));

    return ((triRes && !q) || (q && quadRes)); 
}
```
