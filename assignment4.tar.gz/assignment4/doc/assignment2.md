##	Assignment 2

(This is a continuation tutorial to your Assignment 1 tutorial) 

Your gold model is (hopefully) functional now, but you realize that TAs give you incomplete RTL. 
Assignment 2 challenges you to implement the bounding box function and the sample test function, as well as a finite state machine, which is currently missing in the test iterator module, and then verify the functionality of your design.

###	Instructions

We provide starting code for this part as part of the distribution, including a gold solution from Assignment 1 (after the time Assignment 1 is due). Yet, we encourage you to start Assignment 2 early. 

Rather than waiting, use your Assignment 1 code. The only diﬀerence is that after Assignment 1 is due, we will provide a solution with a complete gold model (thus students that do not do very well on assignment 1, can still do well on assignment 2). 

As with Assignment 1, make sure you are first inside of tcsh before proceeding...
```
tcsh
```
and that you have sourced the class setup file...
```
source setup_ee271.cshrc
```

0. Become familiar with the design and verification environment
```
make debug
```
will open up Verdi and show you the module hierarchy on the left side. Click on modules to see the corresponding source files. Click Tools (on the toolbar) -> New Schematic from Source -> New Schematic to view a schematic of the overall design. 
Back in the source code tab, double click on signals to trace drivers and right click for more options, including tracing loads. Become familiar with the overall design in each of the modules.

1.	Implement bbox module:
The bbox module is located at [`rtl/bbox.sv`](../rtl/bbox.sv). There are three tasks you need to do. The first one is to determine a bounding box represented by the vertices. 
The second task is to clamp the bounding box to the sub-sample pixel space. Then you need to clip the bounding box to screen space and output the final bounding box and its valid signal. 
We have declared the signals that connect these three steps to guide your design. You may want to declare other intermediate signals. There are some useful comments in the code. 
Please read them carefully. You should also refer to the description in Section 4.1.

2.	Implement test iterator’s FSM:
The incomplete FSM is located at [`rtl/test_iterator.sv`](../rtl/test_iterator.sv). The FSM should be able to iterate across the bounding box and output the sample points to next stage. 
To allow you to explore diﬀerent FSM designs, we set up a Systemverilog parameter `MOD_FSM` and two branches later in the code. You only need to implement ONE FSM in the first branch 
and you can revisit it for performance improvement in the third part of this project. However, if you can come up with a better FSM design, please implement it in the second if branch in test iterator. 
There are some useful comments in the code. Please read them carefully. You should also refer to the description in Section 4.2. To use the modified FSM, you can set `MOD_FSM=1` in the
parameter definition of `test_iterator.sv` (line 92).

3.	Implement sample test module:
The sample test module is located at [`rtl/sampletest.sv`](../rtl/sampletest.sv). Your job is to produce the value for `hit_valid_R16H` signal, which indicates whether a sample 
lies inside the triangle. The signal is high if the input sample is valid and the sample is inside the triangle (consider back-face culling). We have declared some helper signals. 
If you want, you can follow suggested steps (see comments in code) and use these helper signals. However, you are free to choose how to implement it, as long as you can produce the correct 
value for the `hit_valid_signal`. As always, please read the comments carefully.

4. Implement verification for the hash module 
The smpl_cnt_sb module is located at [`verif/smpl_cnt_sb.sv`](../verif/smpl_cnt_sb.sv), and the interface between the testbench and the gold model is located at [`gold/rasterizer_sv_interface.c`](gold/rasterizer_sv_interface.c). The check_hash function checks that for a given sample, the jitter value and the jittered sample are correct. Import and call this function in [`verif/smpl_cnt_sb.sv`](../verif/smpl_cnt_sb.sv).

5.	Run verification:
After you complete your RTL code, run the testbench to check your design:
```
$: make run RUN="+testname=$EE271_VECT/vec_271_01_sv_short.dat"
```

As you may already know, there are more test vectors and reference images in `$EE271_VECT` folder. You should try to run simulation using short test vectors first, since the long vectors will take a long time.

If your simulation shows a mismatch between the gold and RTL, you are now entering the DEBUG phase of logic design.

The best way to debug is with a waveform. Generate a waveform by using run_wave instead of run:

```
$: make run_wave RUN="+testname=$EE271_VECT/vec_271_01_sv_short.dat"
```

And then launch Verdi with the waveform:
```
make debug_wave
```

The scoreboard should have specified the signals that mismatch at a given time. Open up the corresponding module, and add signals to the waveform by right-clicking on the signal name in the source code, and selecting "Add to waveform". Double click on signals to find their drivers, and add those to the waveform as well. It may be helpful to turn on Active Annotation (Source->Active Annotation). In the waveform window on the bottom, change the time (right of the golden arrow) to the time at which the simulation reported the error. 

Besides looking at the waveform, it's also helpful to look at values in a schematic. Click on a signal in the source window, and then click on Tools->New schematic from Source->Fan-in Cone. From here, it might be useful to see all the net names in the schematic, which can be turned on by View->Net name in the schematic window toolbar.

Resolve all errors, and once the simulation completes successfully, verify that the output matches the corresponding reference image:
```
$: diff verif_out.ppm $EE271_VECT/vec_271_01_sv_short_ref.ppm
```


It is time to take a look at the performance of your design. You should be able see two performance numbers `triangle/cycle` and `cycle/triangle` at the end of the simulation, which are literally the average number of triangles processed per cycle and its reciprocal collected by a performance monitor `perf_monitor` in the testbench. Note the actual values of these numbers depend on the test vectors you are running. 
For example, if the input has a lot large triangles rather than triangles, like `vec_271_00_sv.dat`, your `triangle/-` cycle must be lower than those from triangles test vectors. You should be able to get more real numbers from running full size triangle rendered image inputs, i.e. `vec_271_01_sv.dat`, `vec_271_02_sv.dat` and `vec_271_04_sv.dat`.

If you implemented another FSM in the second if branch in `test_iterator` and want to run verification with the modified FSM, you can change the default value of 
SystemVerilog parameter `MOD_FSM` to `1` in test_iterator and run verification (and later synthesis) again. 

After passing the verification, you can check the performance of a different FSM design.

We have also provided you some debug assertions. You might find it easier to run formal verification, as it provides a faster counterexample. The length of the bounded model checker is set by bmc_length parameter in the problem.txt file. Set it initially to a smaller value (bmc_length = 5), 
you can increase it once you are confident enough that your code is correct.

Instructions to run formal verification can be found at the end of the assignment.

6.	Run synthesis:
Run synthesis from the project directory:
```
$ make run_dc
```
The directory `reports` inside the `synth` directory contains a number of reports related to the synthesis run. You are interested in the file `timing_report_max`, which contains the longest paths in the design. The report will list the path signal names and whether the path has violated timing. The first and last signals in the critical path should contain an instance name related to a flip flop. Since we have turned on retiming, 
the dff instance name will change after synthesis tool moves it around. So in order to correlate the signal names, you want to check the name of dff’s parent instance carried in the signal name and get a sense of where the critical path is. For example, `sampletest/DP_OP_28J1_125_9254/clk_r_REG379_S13/D` is the name of the last signal in a critical path. `DP_OP_28J1_125_9254` is obviously a tool-generated name rather than a given name in RTL. 
However, you can some how know that it is a signal connected to the `D` port of a register (flip-flop) inside `sampletest` instance. After you find where the critical path is, you can make changes to the RTL which do not affect its functionality but result in eliminating or improving the critical path, such as retiming.
 
There are a bunch of other handy reports in the `reports` folder. For example, `area_report` summarizes the area information of the chip. `design_check` is a list of synthesis warnings, while `error_checking_report` is a list of errors. Make sure you don’t have any errors, and we will check it in the grading script. `power_report` is the power report of your design.

Once you have made your changes rerun the synthesis script and verify that your fix worked. It is also imperative that you rerun your verification bench in order to make sure that functionality was not adversely aﬀected.

7.	Retiming:
In assignment 2, you only need to have a functionally correct design, that can run synthesis with default clock period and chip area budget. Optimization is the goal of the next assignment. However, you must be interested to see how fast your design can run. You may also want to try some simple techniques, like retiming, to improve the performance.
Now try to run the synthesis again with a faster clock, say 0.8ns, by changing the value of the variable `CLK_PERIOD` in the Makefile. You can do this by running the command `make run_dc CLK_PERIOD=0.8 ...`

After synthesis is done, there will likely be timing violations, since even the powerful synthesis tool fails to put all the logic in each stage into one clock cycle. However, by analysing the timing report, you should be able to see where the critical path is. Recall the retiming technique we have introduced in lectures. We can increase the pipeline depth and move around the registers to break a long combinational path into small slices.

The good thing is that the synthesis tool can handle the retiming pretty well after you tell it how many stages you want to allocate for each part of the pipe. In this project, you can change the pipeline depths of bbox, hash tree and sampletest modules by modifying the SystemVerilog parameters of `params/rast_params.sv` module. Run synthesis again to see the results.

If you are doing this, don’t forget to hard code your final parameter values in the submission, since we use default command for grading.

Try to hit the highest clock rate by retiming. From your results, which design can run at a higher frequency? Think of why this is the case. You should submit a final design which can pass synthesis at default clock period (1.2ns) without any timing violations. Make sure the area of your chip doesn’t exceed 42000(um2), which is the target area in synthesis. (If you put too many pipe stages, the registers will cost area.)

### Formal Verification

For this part, you are expected to write some SystemVerilog Assertions using CoSA in [`rtl/bbox.sv`](../rtl/bbox.sv) and [`rtl/test_iterator.sv`](../rtl/test_iterator.sv). Follow
the comments in the code to find where you should insert your assertions and what properties they should check.

To perform the verification, first move to the formal directory.
```
cd formal
./cat-script.sh
```
The cat-script generates a single file (`rast.sv`) in your formal directory from your project directory to input into CoSA.

Then run
```
CoSA --problems problem.txt
```
You can also run `CoSA --help` if you'd like to see more options.

CoSA will try to prove the assertions defined in your SystemVerilog code. If it's able to successfully prove it, it returns TRUE. Sometimes, it's not able to formally prove it but still cannot find a counterexample in the given bounds, and therefore outputs UNKNOWN. If your bounds are large enough (you don't have to set it, we have set it for you), it is a reasonable guarantee that the assertion is true.

The submission for this part is the output of the command `CoSA --problems problem.txt` with `bmc_length = 10`. You can change `bmc_length` (and other properties) inside of the provided `problem.txt`.


###	Submission

For this part of the assignment, you should submit the correct design with bbox, sampletest, test iterator FSM implemented, and output of COSA. You may have a good number of working design configurations, but please adjust your RTL and SystemVerilog parameters so that in the default configuration, it can run synthesis with default clock period and chip area budget. The submitted RTL code must have correct functionality, 
which means it should be able to pass all the test vectors (short and long vectors). 
This part is graded by correctness (your budget is large enough). However, it’s better to resolve critical paths and hit a higher clock rate. This will place your team in a better position in the Assignment 3 performance competition.

You will receive partial credit if you pass the verification but have timing violation after synthesis.

The DUE date of this assignment is 11/20.
The submission requirement is the same as Assignment 1 (see Section 5.1.2), except to name your folder and tar ball as assignment2. Please clean up your folder, add a names.txt, tar ball it, 
test with the grading script and submit the tar ball on Gradescope .