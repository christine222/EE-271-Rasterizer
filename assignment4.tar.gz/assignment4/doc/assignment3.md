
## Assignment 3
This part of the project will challenge you to meet the hardware speciﬁcation and is more open ended than the prior two assignments. The lead architect has indicated to us that we must render scenes containing 5 million triangles onto a 16xMSAA buﬀer at a rate of 100 Hz. This corresponds to a throughput of 1 triangle every 2ns (i.e. 2ns/triangle or 0.5triangle/ns).

### Instructions
The way to estimate the performance of your design is to take the ’cycle/triangle’ from simulation and multiply it by the clock period from synthesis (make sure the timing is MET) to get the average time to process a miropolygon (ns/triangle).

Your goal here is to build a design that matches the leading architect in performance (2ns/triangle) and then try your best to optimize the power consumption or the chip area or both. One easy way to quickly match the performance is to simply duplicate the hardware instances. We don’t want you to do this duplication in RTL, so in calculation please just state how may copies (should be an integer) of the rasterization pipeline you need to hit the target. Since this graphic application can be well-paralleled, you may assume that throughput scales linearly with the number of instances, but don’t forget to scale the power and area correspondingly at the same time.

After you match the throughput target by simply duplicating hardware or over-clocking, now it is time to do some real optimization to reduce the chip area or power dissipation. Remember VLSI is always about tradeoﬀs, which means here you can easily trade more area for low power and vice versa. Therefore, a good way to evaluate your design optimizations is to look at the tradeoﬀ curve, which is also more or less what we will do to grade your optimization results. Figure 13 shows a reference area-power tradeoﬀ curve of this triangle pipeline after some optimizations. If the point (area, power) of your design is to the lower left of the curve, it means your design is better than the reference design and vice versa. The figure of merit is Area * Power * Num_Rasterizer_Units^2. A lower FoM is better.

![Area versus Power Trade-off Curve](img/figure13.png)

Figure 13: Area versus Power Trade-off Curve

The following list of ideas will be helpful in this assignment.

**Code Optimization**: For the same logic, the way you implement it could make a diﬀerence to the synthesized hardware, and thus the timing, area, and power.

**FSM**: Continue to optimize the FSM in the test iterator. Try to eliminate wasted cycles, make critical paths inside shorter, minimize the numbers of states (registers), or build a completely new FSM.

**Retiming**: If you decrease the clock period it would increase throughput. See Assignment 2 for instructions.

**BackFace Culling**: Currently the design waits until sample test time to determine if a triangle is backfacing or forward facing and only for individual samples. Performing the test earlier would eliminate those extra tests and improve throughput.

**Lower Precision**: High precision operations, like multiplications, are expensive in terms of delay, power and area. Try to optimize the precision of your arithmetic operations, but be careful that this optimization should not change the results. You still need to generate the same images as corresponding reference images. No error at output is tolerable.

**Bubble Smashing**: In the current design it is possible for bubbles to appear between triangles during the bounding box stage. While halted it may be useful to advance a triangle into a pipe stage which doesn’t hold any values. This will be especially useful if you implement backface culling.

**MultiTest**: Testing multiple samples per cycle is a sure way to increase throughput. This change will impact the verification collateral, be sure to maintain consistency between the two.

**Better Bounding Box**: The bounding box method is only one method of iterating over the samples that might appear in a bounding box. There are many others. One of these other methods might help you reach the throughput you need. One algorithm you might try is given in this work.

**Clock Gating**: Clock gating is a technique, which enable you to dynamically prune the clock tree. When you disable the clock signal to those parts that don’t generate valid values, you save all the dynamic energy dissipation (leakage still there) in those parts.

**Be Creative**: Find a way to increase the throughput not listed here.

**Last  but  Not  Least**: Try to do some research on this topic, sometimes it is important to stand on the shoulders of giants. Here is a good starting paper.

To be able to do well on this assignment you **should**:

1. **Predict the Efficacy of Your Approach**: Using back of the envelope calculations predict what the eﬀect of your change will be. It is very important that you attempt to quantify your changes in advance. Failing to do so can result in significant amounts of work with only minor performance benefits. Go for the lowest hanging fruit, and the biggest bang for the buck!

2. **Measure Throughput**: Using the verification environment, calculate your throughput in triangles per cycle. Use the various traces and to measure the incremental benefits of each of your changes.

3. **Verify Your Design**: Using the verification environment provided, plus verification environment modifications you needed to make to accommodate your functional changes, test your design. Then test it again. And again. Be thorough!

4. **Synthesize Your Design**: Make sure that your design meets timing and is still synthesizeable. You can alter the clock period in the synthesis script if this is the approach you wish to take.

5. **Check Your Specification**: The report directory also contains a power report and area report which you can use to evaluate whether your design is inside the power and area limits.

### Write-Up

For the write-up, please report the following:

- **Total Dynamic Power (mW)**

- **Total Leakage Power (mW)**

- **Total Power (mW)**

- **Total Area (mm^2)**

- **Total Performance (triangles/second)**

- **Number of Rasterization Units**

- **Clock Speed (ns)**

List all optimizations, and for each, report (no more than 1 page per optimization):

- **Before implementing the optimization, how did you evaluate the efficacy of the optimization? How did you estimate cost and performance?**

- **How did you implement the optimization?  Was there anything particularly difficult that you were not expecting?**

- **What were the actual changes in cost and performance? How/Why did this deviate from your estimation?**

- **You are encouraged to include effective and clear figures or plots to help comment on any of the above.**

- **It’s helpful to include tables or plots to compare the change of the throughout, the number of rasterization units needed, the clock period, the total power, and the total area for each of your optimizations.**

Finally:

- **Is there any analysis/discussion that you did for the project that you would like to share (no more than a page)?**

- **Please provide any concluding thoughts on the project and share anything you think that can improve the design.**


### Submission
For this part of the assignment you will submit the final RTL design and a short write-up detailing your work. There will be two submissions - report and the assignment3 tar ball. Submit both together on Gradescope.

The DUE date of this assignment is 12/4.

The requirement for RTL submission is the same as Assignment 1 (see Section 5.1.2), expect to name your folder and tar ball as assignment3. Please clean up your folder, add a names.txt, tar ball it, test with the grading script and submit the tar ball on Gradescope.
The grade of this assignment consists of two parts: 60% for the optimization result and 40% for the write-up report. The optimization result part will be graded relatively based on the results of the class.