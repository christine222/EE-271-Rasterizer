#!/bin/bash
FILES_MAGMA=magma/*
FILES_HLS=hls/src/*

cd ../
rm -rf rasterizer_distrib
cp -rf rasterizer_clean rasterizer_distrib
cd rasterizer_distrib
rm -rf .git
rm .gitignore

for f in $FILES_MAGMA
do
  echo "Processing $f"
  awk -f proc_magma.awk $f > tmp && mv tmp "$f"
done

for f in $FILES_HLS
do
  echo "Processing $f"
  awk -f proc.awk $f > tmp && mv tmp "$f"
done

cd ../
tar -zcvf rast_dist.tar.gz rasterizer_distrib/
rm rasterizer/rast_dist.tar.gz
cp -f rast_dist.tar.gz rasterizer/
rm -rf rasterizer_distrib/
